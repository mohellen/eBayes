dot -Tpng module_dependencies.dot -o module_dependencies.png
